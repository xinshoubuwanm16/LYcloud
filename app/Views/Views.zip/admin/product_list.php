<?php /** 后台商品列表 */
$catMap     = $catMap ?? [];
$categories = $categories ?? [];
$catFilter  = $catFilter ?? '';
?>
<div class="card">
    <div class="card-head">
        <h3>商品管理 <small>共 <?= (int)$total ?> 个</small></h3>
        <div class="head-actions">
            <form class="search-form" method="get" action="<?= url('admin/product/list') ?>">
                <input type="hidden" name="r" value="admin/product/list">
                <input type="text" name="keyword" value="<?= e($keyword) ?>" placeholder="搜索商品名称">
                <select name="category">
                    <option value="">全部分类</option>
                    <option value="0"<?= $catFilter === 0 ? ' selected' : '' ?>>未分类</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= (int)$c['id'] ?>"<?= $catFilter === (int)$c['id'] ? ' selected' : '' ?>><?= e($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="btn btn-sm btn-ghost" type="submit">筛选</button>
            </form>
            <a class="btn btn-primary btn-sm" href="<?= url('admin/product/form') ?>">+ 添加商品</a>
        </div>
    </div>

    <?php if (!$rows): ?>
        <div class="empty-line">暂无商品，点击右上角「添加商品」创建第一个套餐</div>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th style="width:60px">ID</th>
                <th>商品名称</th>
                <th style="width:110px">分类</th>
                <th style="width:110px">售价</th>
                <th style="width:130px">交付方式</th>
                <th style="width:110px">可用库存</th>
                <th style="width:80px">已售</th>
                <th style="width:100px">限购</th>
                <th style="width:80px">状态</th>
                <th style="width:230px">操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $p): ?>
            <?php
            $dm = \App\Models\Product::normalizeDeliverMode((int)($p['deliver_mode'] ?? 1));
            $dmBadge = [1 => 'badge-info', 2 => 'badge-ok', 3 => 'badge-warn'][$dm] ?? 'badge-muted';
            $pCat = $catMap[(int)($p['category_id'] ?? 0)] ?? null;
            ?>
            <tr>
                <td class="mono"><?= (int)$p['id'] ?></td>
                <td>
                    <div class="cell-main"><?= e($p['name']) ?></div>
                    <?php if ($p['subtitle'] !== ''): ?>
                        <div class="cell-sub"><?= e($p['subtitle']) ?></div>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($pCat): ?>
                        <?php $pStyle = \App\Models\Category::colorStyle($pCat); ?>
                        <span class="badge cat-badge"<?= $pStyle !== '' ? ' style="' . e($pStyle) . '"' : '' ?>><?= e($pCat['name']) ?></span>
                        <?php if ((int)$pCat['status'] !== 1): ?><div class="cell-sub">分类已隐藏</div><?php endif; ?>
                    <?php else: ?>
                        <span class="badge badge-muted">未分类</span>
                    <?php endif; ?>
                </td>
                <td class="text-price">¥<?= money($p['price']) ?></td>
                <td>
                    <span class="badge <?= $dmBadge ?>"><?= e(\App\Models\Product::DELIVER_TEXT[$dm]) ?></span>
                    <?php if ($dm === \App\Models\Product::DELIVER_MNBT): ?>
                        <div class="cell-sub"><?= e(\App\Models\Product::mnbtTypeText($p)) ?> · <?= e(\App\Models\Product::mnbtSpecText($p)) ?></div>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($dm === \App\Models\Product::DELIVER_MNBT): ?>
                        <span class="badge badge-muted" title="MNBT 商品由接口实时开通，不占用本站库存池">现开</span>
                    <?php elseif ((int)$p['stock_mode'] === 1): ?>
                        <span class="badge <?= $p['stock_count'] <= 0 ? 'badge-danger' : ($p['stock_count'] < 3 ? 'badge-warn' : 'badge-ok') ?>">
                            <?= (int)$p['stock_count'] ?> 条
                        </span>
                    <?php else: ?>
                        <span class="badge badge-info">不限量</span>
                    <?php endif; ?>
                </td>
                <td><?= (int)$p['sold_count'] ?></td>
                <td>
                    <?php $lim = (int)($p['limit_per_user'] ?? 0); ?>
                    <?php if ($lim > 0): ?>
                        <span class="badge badge-warn">限 <?= $lim ?> 次</span>
                    <?php else: ?>
                        <span class="badge badge-muted">不限购</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="badge <?= (int)$p['status'] === 1 ? 'badge-ok' : 'badge-muted' ?>">
                        <?= (int)$p['status'] === 1 ? '已上架' : '已下架' ?>
                    </span>
                </td>
                <td class="ops">
                    <a class="btn btn-xs btn-ghost" href="<?= url('admin/product/form', ['id' => (int)$p['id']]) ?>">编辑</a>
                    <?php if ($dm !== \App\Models\Product::DELIVER_MNBT): ?>
                        <a class="btn btn-xs btn-ghost" href="<?= url('admin/stock/list', ['product_id' => (int)$p['id']]) ?>">库存</a>
                    <?php endif; ?>
                    <form method="post" action="<?= url('admin/product/toggle') ?>" class="inline">
                        <?= \App\Auth::csrfField() ?>
                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                        <button class="btn btn-xs btn-ghost" type="submit"><?= (int)$p['status'] === 1 ? '下架' : '上架' ?></button>
                    </form>
                    <form method="post" action="<?= url('admin/product/delete') ?>" class="inline js-confirm"
                          data-confirm="确定删除商品「<?= e($p['name']) ?>」吗？未售库存将一并删除。">
                        <?= \App\Auth::csrfField() ?>
                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                        <button class="btn btn-xs btn-danger" type="submit">删除</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?= paginate((int)$total, (int)$perPage, (int)$page, 'admin/product/list', ['keyword' => $keyword, 'category' => $catFilter]) ?>
    <?php endif; ?>
</div>

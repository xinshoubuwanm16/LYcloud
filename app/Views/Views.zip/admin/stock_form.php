<?php /** 单条库存编辑 */
$isEdit = (bool)$stock;
$v = function ($key, $default = '') use ($stock) {
    if (isset($_POST[$key])) return $_POST[$key];
    return $stock[$key] ?? $default;
};
?>
<div class="card">
    <div class="card-head">
        <h3><?= $isEdit ? '编辑面板信息' : '添加面板信息' ?></h3>
        <a class="btn btn-sm btn-ghost" href="<?= url('admin/stock/list') ?>">← 返回库存列表</a>
    </div>

    <form method="post" action="<?= url('admin/stock/save') ?>" class="form-horizontal">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="id" value="<?= (int)($stock['id'] ?? 0) ?>">

        <div class="form-row">
            <label>所属商品 <em>*</em></label>
            <div class="form-control">
                <select name="product_id" required>
                    <option value="">— 请选择 —</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?= (int)$p['id'] ?>" <?= (int)$v('product_id') === (int)$p['id'] ? 'selected' : '' ?>>
                            #<?= (int)$p['id'] ?> <?= e($p['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <label>面板登录链接 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="panel_url" value="<?= e($v('panel_url')) ?>"
                       placeholder="http://[2408:xxxx::1]:8888/abcdef" required maxlength="250">
            </div>
        </div>

        <div class="form-row">
            <label>面板账号 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="panel_user" value="<?= e($v('panel_user')) ?>" required maxlength="110">
            </div>
        </div>

        <div class="form-row">
            <label>面板密码 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="panel_pass" value="<?= e($v('panel_pass')) ?>" required maxlength="110">
            </div>
        </div>

        <div class="form-row">
            <label>备注</label>
            <div class="form-control">
                <input type="text" name="remark" value="<?= e($v('remark')) ?>" placeholder="到期时间 / 节点位置等" maxlength="250">
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary"><?= $isEdit ? '保存修改' : '添加' ?></button>
            <a class="btn btn-ghost" href="<?= url('admin/stock/list') ?>">取消</a>
        </div>
    </form>
</div>

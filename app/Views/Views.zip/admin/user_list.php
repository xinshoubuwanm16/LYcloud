<?php /** 后台用户列表 */ ?>
<div class="card">
    <div class="card-head">
        <h3>用户管理 <small>共 <?= (int)$total ?> 人</small></h3>
        <form class="search-form" method="get" action="<?= url('admin/user/list') ?>">
            <input type="hidden" name="r" value="admin/user/list">
            <input type="text" name="keyword" value="<?= e($keyword) ?>" placeholder="搜索邮箱或昵称">
            <button class="btn btn-sm btn-ghost" type="submit">搜索</button>
        </form>
    </div>

    <?php if (!$rows): ?>
        <div class="empty-line">暂无用户</div>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th style="width:60px">ID</th>
                <th>邮箱</th>
                <th style="width:130px">昵称</th>
                <th style="width:90px">订单数</th>
                <th style="width:110px">累计消费</th>
                <th style="width:110px">余额</th>
                <th style="width:90px">状态</th>
                <th style="width:160px">注册时间</th>
                <th style="width:250px">操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $u): ?>
            <tr>
                <td class="mono"><?= (int)$u['id'] ?></td>
                <td><?= e($u['email']) ?></td>
                <td><?= e($u['nickname']) ?></td>
                <td><?= (int)$u['order_count'] ?></td>
                <td class="text-price">¥<?= money($u['total_paid']) ?></td>
                <td class="text-price">¥<?= money($u['balance']) ?></td>
                <td>
                    <span class="badge <?= (int)$u['status'] === 1 ? 'badge-ok' : 'badge-danger' ?>">
                        <?= (int)$u['status'] === 1 ? '正常' : '已禁用' ?>
                    </span>
                </td>
                <td class="mono"><?= e($u['created_at']) ?></td>
                <td class="ops">
                    <form method="post" action="<?= url('admin/user/toggle') ?>" class="inline">
                        <?= \App\Auth::csrfField() ?>
                        <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                        <input type="hidden" name="page" value="<?= (int)$page ?>">
                        <button class="btn btn-xs btn-ghost" type="submit"><?= (int)$u['status'] === 1 ? '禁用' : '启用' ?></button>
                    </form>
                    <button class="btn btn-xs btn-ghost" type="button"
                            onclick="adjustBal(<?= (int)$u['id'] ?>, '<?= e($u['email']) ?>', '<?= money($u['balance']) ?>')">调整余额</button>
                    <button class="btn btn-xs btn-ghost" type="button"
                            onclick="resetPwd(<?= (int)$u['id'] ?>, '<?= e($u['email']) ?>')">重置密码</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?= paginate((int)$total, (int)$perPage, (int)$page, 'admin/user/list', ['keyword' => $keyword]) ?>
    <?php endif; ?>
</div>

<!-- 重置密码弹窗 -->
<div class="modal-mask" id="resetModal">
    <div class="modal-box">
        <h3>重置用户密码</h3>
        <p class="modal-sub" id="resetEmail"></p>
        <form method="post" action="<?= url('admin/user/resetPassword') ?>">
            <?= \App\Auth::csrfField() ?>
            <input type="hidden" name="id" id="resetId" value="">
            <div class="form-item">
                <label>新密码（至少 6 位）</label>
                <input type="text" name="new_password" id="resetPwdInput" required minlength="6" placeholder="输入新密码">
            </div>
            <div class="modal-actions">
                <button class="btn btn-primary" type="submit">确认重置</button>
                <button class="btn btn-ghost" type="button" onclick="closeReset()">取消</button>
            </div>
        </form>
    </div>
</div>

<script>
function resetPwd(id, email) {
    document.getElementById('resetId').value = id;
    document.getElementById('resetEmail').textContent = '账号：' + email;
    var pw = 'LY' + Math.random().toString(36).slice(2, 10);
    document.getElementById('resetPwdInput').value = pw;
    document.getElementById('resetModal').classList.add('show');
}
function closeReset() {
    document.getElementById('resetModal').classList.remove('show');
}

function adjustBal(id, email, balance) {
    document.getElementById('adjId').value = id;
    document.getElementById('adjEmail').textContent = '账号：' + email;
    document.getElementById('adjCurrent').textContent = '当前余额：¥' + balance;
    document.getElementById('adjAmount').value = '';
    document.getElementById('adjRemark').value = '';
    document.getElementById('adjModal').classList.add('show');
}
function closeAdj() {
    document.getElementById('adjModal').classList.remove('show');
}
</script>

<!-- 调整余额弹窗 -->
<div class="modal-mask" id="adjModal">
    <div class="modal-box">
        <h3>调整用户余额</h3>
        <p class="modal-sub" id="adjEmail"></p>
        <p class="modal-sub" id="adjCurrent"></p>
        <form method="post" action="<?= url('admin/user/adjustBalance') ?>">
            <?= \App\Auth::csrfField() ?>
            <input type="hidden" name="id" id="adjId" value="">
            <input type="hidden" name="page" value="<?= (int)$page ?>">
            <input type="hidden" name="keyword" value="<?= e($keyword) ?>">
            <div class="form-item">
                <label>调整金额（正数充值，负数扣减）</label>
                <input type="text" name="amount" id="adjAmount" required
                       placeholder="例如 100 或 -50" autocomplete="off">
            </div>
            <div class="form-item">
                <label>备注（可选，写入余额流水）</label>
                <input type="text" name="remark" id="adjRemark" maxlength="60"
                       placeholder="例如：活动补偿">
            </div>
            <div class="modal-actions">
                <button class="btn btn-primary" type="submit">确认调整</button>
                <button class="btn btn-ghost" type="button" onclick="closeAdj()">取消</button>
            </div>
        </form>
    </div>
</div>


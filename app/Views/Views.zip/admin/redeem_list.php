<?php
/** 后台兑换码列表 */
$statusMap = [
    0 => ['未使用', 'badge-ok'],
    1 => ['已使用', 'badge-info'],
    2 => ['已作废', 'badge-muted'],
];
?>
<div class="card">
    <div class="card-head">
        <h3>兑换码管理 <small>共 <?= (int)$total ?> 个</small></h3>
        <div class="head-actions">
            <form method="post" action="<?= url('admin/redeem/cleanExpired') ?>" class="inline js-confirm"
                  data-confirm="确定清理所有已过期且未使用的兑换码吗？">
                <?= \App\Auth::csrfField() ?>
                <button class="btn btn-sm btn-ghost" type="submit">清理过期码</button>
            </form>
            <button class="btn btn-sm btn-primary" type="button" onclick="openGen()">生成兑换码</button>
        </div>
    </div>

    <!-- 统计 -->
    <div class="stat-row">
        <div class="stat-box">
            <span>总数</span><b><?= (int)$stats['total'] ?></b>
        </div>
        <div class="stat-box">
            <span>未使用</span><b class="c-ok"><?= (int)$stats['unused'] ?></b>
        </div>
        <div class="stat-box">
            <span>已使用</span><b class="c-info"><?= (int)$stats['used'] ?></b>
        </div>
        <div class="stat-box">
            <span>已作废</span><b class="c-muted"><?= (int)$stats['void'] ?></b>
        </div>
        <div class="stat-box">
            <span>已兑换金额</span><b class="c-price">¥<?= money($stats['issued_amount']) ?></b>
        </div>
    </div>

    <!-- 筛选 -->
    <form class="search-form filter-form" method="get" action="<?= url('admin/redeem/list') ?>">
        <input type="hidden" name="r" value="admin/redeem/list">
        <input type="text" name="keyword" value="<?= e($keyword) ?>" placeholder="掩码或完整兑换码">
        <input type="text" name="batch_no" value="<?= e($batchNo) ?>" placeholder="批次号">
        <select name="status">
            <option value="">全部状态</option>
            <option value="0"<?= (string)$status === '0' ? ' selected' : '' ?>>未使用</option>
            <option value="1"<?= (string)$status === '1' ? ' selected' : '' ?>>已使用</option>
            <option value="2"<?= (string)$status === '2' ? ' selected' : '' ?>>已作废</option>
        </select>
        <button class="btn btn-sm btn-ghost" type="submit">筛选</button>
        <a class="btn btn-sm btn-ghost" href="<?= url('admin/redeem/list') ?>">重置</a>
    </form>

    <?php if (!$rows): ?>
        <div class="empty-line">暂无兑换码，点击右上角「生成兑换码」开始创建</div>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th style="width:56px">ID</th>
                <th style="width:150px">兑换码</th>
                <th style="width:100px">面额</th>
                <th style="width:80px">状态</th>
                <th style="width:190px">批次号</th>
                <th style="width:160px">有效期至</th>
                <th>备注 / 使用人</th>
                <th style="width:160px">创建时间</th>
                <th style="width:90px">操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $c):
                $st = (int)$c['status'];
                $s = $statusMap[$st] ?? ['未知', 'badge-muted'];
                $expired = $c['expires_at'] !== null && strtotime((string)$c['expires_at']) < time() && $st === 0;
            ?>
            <tr>
                <td class="mono"><?= (int)$c['id'] ?></td>
                <td class="mono"><?= e($c['code_mask']) ?></td>
                <td class="text-price">¥<?= money($c['amount']) ?></td>
                <td>
                    <span class="badge <?= $s[1] ?>"><?= $s[0] ?></span>
                    <?php if ($expired): ?>
                        <span class="badge badge-warn" title="已过期，尚未兑换">已过期</span>
                    <?php endif; ?>
                </td>
                <td class="mono"><?= e($c['batch_no']) ?></td>
                <td class="mono"><?= $c['expires_at'] ? e($c['expires_at']) : '<span class="c-muted">永久有效</span>' ?></td>
                <td>
                    <?php if (!empty($c['remark'])): ?>
                        <div class="cell-sub"><?= e($c['remark']) ?></div>
                    <?php endif; ?>
                    <?php if ((int)$c['used_by'] > 0): ?>
                        <div class="cell-sub">使用者 ID：<?= (int)$c['used_by'] ?>
                            <?= $c['used_at'] ? ' · ' . e($c['used_at']) : '' ?>
                        </div>
                    <?php endif; ?>
                    <?php if (empty($c['remark']) && (int)$c['used_by'] === 0): ?>
                        <span class="c-muted">—</span>
                    <?php endif; ?>
                </td>
                <td class="mono"><?= e($c['created_at']) ?></td>
                <td class="ops">
                    <?php if ($st === 0): ?>
                    <form method="post" action="<?= url('admin/redeem/void') ?>" class="inline js-confirm"
                          data-confirm="确定作废该兑换码吗？作废后无法恢复。">
                        <?= \App\Auth::csrfField() ?>
                        <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                        <input type="hidden" name="page" value="<?= (int)$page ?>">
                        <input type="hidden" name="status" value="<?= e((string)$status) ?>">
                        <input type="hidden" name="batch_no" value="<?= e($batchNo) ?>">
                        <input type="hidden" name="keyword" value="<?= e($keyword) ?>">
                        <button class="btn btn-xs btn-danger" type="submit">作废</button>
                    </form>
                    <?php else: ?>
                        <span class="c-muted">—</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?= paginate((int)$total, (int)$perPage, (int)$page, 'admin/redeem/list', [
        'status'   => $status,
        'batch_no' => $batchNo,
        'keyword'  => $keyword,
    ]) ?>
    <?php endif; ?>
</div>

<!-- 最近批次 -->
<?php if ($batches): ?>
<div class="card">
    <div class="card-head">
        <h3>最近批次 <small>近 <?= count($batches) ?> 批</small></h3>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th style="width:190px">批次号</th>
                <th style="width:100px">面额</th>
                <th style="width:70px">总数</th>
                <th style="width:80px">未使用</th>
                <th style="width:80px">已使用</th>
                <th style="width:80px">已作废</th>
                <th style="width:160px">创建时间</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($batches as $b): ?>
            <tr>
                <td class="mono"><?= e($b['batch_no']) ?></td>
                <td class="text-price">¥<?= money($b['amount']) ?></td>
                <td><?= (int)$b['total'] ?></td>
                <td><span class="badge badge-ok"><?= (int)$b['unused'] ?></span></td>
                <td><span class="badge badge-info"><?= (int)$b['used'] ?></span></td>
                <td><span class="badge badge-muted"><?= (int)$b['void_cnt'] ?></span></td>
                <td class="mono"><?= e($b['created_at']) ?></td>
                <td class="ops">
                    <a class="btn btn-xs btn-ghost" href="<?= url('admin/redeem/list', ['batch_no' => $b['batch_no']]) ?>">查看</a>
                    <?php if ((int)$b['unused'] > 0): ?>
                    <form method="post" action="<?= url('admin/redeem/voidBatch') ?>" class="inline js-confirm"
                          data-confirm="确定作废该批次中所有未使用的兑换码吗？">
                        <?= \App\Auth::csrfField() ?>
                        <input type="hidden" name="batch_no" value="<?= e($b['batch_no']) ?>">
                        <button class="btn btn-xs btn-danger" type="submit">作废未用</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<!-- 生成弹窗 -->
<div class="modal-mask" id="genModal">
    <div class="modal-box">
        <h3>生成兑换码</h3>
        <p class="modal-sub">
            生成后明文只显示一次，请及时复制保存。系统仅存储哈希值，关闭页面后无法再次查看。
        </p>
        <form method="post" action="<?= url('admin/redeem/generate') ?>">
            <?= \App\Auth::csrfField() ?>
            <div class="form-item">
                <label>生成数量（1 ~ <?= (int)\App\Models\RedeemCode::MAX_BATCH ?>）</label>
                <input type="number" name="count" min="1" max="<?= (int)\App\Models\RedeemCode::MAX_BATCH ?>"
                       value="10" required>
            </div>
            <div class="form-item">
                <label>单张面额（元，<?= money($minAmount) ?> ~ <?= money($maxAmount) ?>）</label>
                <input type="text" name="amount" required
                       placeholder="<?= money($minAmount) ?>" value="10.00">
            </div>
            <div class="form-item">
                <label>有效期天数（留空 = 永久有效）</label>
                <input type="number" name="ttl_days" min="0" max="3650" placeholder="例如 30，留空则永久有效">
            </div>
            <div class="form-item">
                <label>备注（可选）</label>
                <input type="text" name="remark" maxlength="240" placeholder="例如：双十一活动批次">
            </div>
            <div class="modal-actions">
                <button class="btn btn-primary" type="submit">确认生成</button>
                <button class="btn btn-ghost" type="button" onclick="closeGen()">取消</button>
            </div>
        </form>
    </div>
</div>

<script>
function openGen() { document.getElementById('genModal').classList.add('show'); }
function closeGen() { document.getElementById('genModal').classList.remove('show'); }
</script>

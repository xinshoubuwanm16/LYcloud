<?php /** 后台系统设置 */ 
$tab = input('tab', 'alipay');
$s = $settings;
$g = function ($k, $d = '') use ($s) { return $s[$k] ?? $d; };
?>
<div class="tabs">
    <a class="tab <?= $tab === 'alipay' ? 'on' : '' ?>" href="<?= url('admin/setting/index', ['tab' => 'alipay']) ?>">支付宝接口</a>
    <a class="tab <?= $tab === 'yipay' ? 'on' : '' ?>" href="<?= url('admin/setting/index', ['tab' => 'yipay']) ?>">易支付<?= empty($yipayReady) ? '' : ' ✓' ?></a>
    <a class="tab <?= $tab === 'donate' ? 'on' : '' ?>" href="<?= url('admin/setting/index', ['tab' => 'donate']) ?>">捐赠收款码<?= empty($donateReady) ? '' : ' ✓' ?></a>
    <a class="tab <?= $tab === 'mail' ? 'on' : '' ?>" href="<?= url('admin/setting/index', ['tab' => 'mail']) ?>">
        邮件设置<?= empty($smtpReady) ? '' : ' ✓' ?>
    </a>
    <a class="tab <?= $tab === 'mnbt' ? 'on' : '' ?>" href="<?= url('admin/setting/index', ['tab' => 'mnbt']) ?>">MNBT对接<?= empty($mnbtReady) ? '' : ' ✓' ?></a>
    <a class="tab <?= $tab === 'site' ? 'on' : '' ?>" href="<?= url('admin/setting/index', ['tab' => 'site']) ?>">站点设置</a>
    <a class="tab <?= $tab === 'sys' ? 'on' : '' ?>" href="<?= url('admin/setting/index', ['tab' => 'sys']) ?>">系统信息</a>
</div>

<?php if ($tab === 'alipay'): ?>

<div class="card">
    <div class="card-head">
        <h3>支付宝接口配置</h3>
        <?php if ($alipayReady): ?>
            <span class="badge badge-ok">已配置</span>
        <?php else: ?>
            <span class="badge badge-warn">未配置</span>
        <?php endif; ?>
    </div>

    <div class="notice-box small">
        <h4>配置步骤</h4>
        <ol>
            <li>登录 <a href="https://open.alipay.com/" target="_blank" rel="noopener">支付宝开放平台</a>，进入「控制台 → 网页/移动应用 → 创建应用」。</li>
            <li>在应用详情中开通 <b>「当面付」</b>（扫码支付）和 <b>「电脑网站支付」</b> 产品权限。</li>
            <li>进入「开发设置 → 接口加签方式」，使用 <b>公钥模式（RSA2）</b>。可点击下方按钮生成密钥对，
                然后把 <b>应用公钥</b> 填入支付宝后台，保存后将 <b>支付宝公钥</b> 复制回来填到本页。</li>
            <li>回到本页填写 <b>APPID</b>、<b>应用私钥</b>、<b>支付宝公钥</b>，选择网关环境与支付方式后保存。</li>
            <li>在支付宝开放平台「应用信息 → 开发设置」中，把本页给出的 <b>授权回调地址 / 异步通知地址</b> 填入（部分产品可不填，由请求参数携带）。</li>
        </ol>
    </div>

    <form method="post" action="<?= url('admin/setting/save') ?>" class="form-horizontal">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="group" value="alipay">

        <div class="form-row">
            <label>默认支付方式</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="alipay_mode" value="qr" <?= $g('alipay_mode', 'qr') === 'qr' ? 'checked' : '' ?>>
                    当面付（扫码支付）— 页面展示二维码，用户支付宝扫码付款
                </label>
                <label class="radio">
                    <input type="radio" name="alipay_mode" value="page" <?= $g('alipay_mode') === 'page' ? 'checked' : '' ?>>
                    电脑网站支付 — 跳转支付宝收银台完成付款
                </label>
                <small>用户下单时仍可自行切换，此处为默认值</small>
            </div>
        </div>

        <div class="form-row">
            <label>网关环境</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="alipay_gateway" value="sandbox" <?= $g('alipay_gateway', 'sandbox') === 'sandbox' ? 'checked' : '' ?>>
                    沙箱环境（开发测试）
                </label>
                <label class="radio">
                    <input type="radio" name="alipay_gateway" value="prod" <?= $g('alipay_gateway') === 'prod' ? 'checked' : '' ?>>
                    正式环境（生产收款）
                </label>
            </div>
        </div>

        <div class="form-row">
            <label>APPID <em>*</em></label>
            <div class="form-control">
                <input type="text" name="alipay_app_id" value="<?= e($g('alipay_app_id')) ?>" placeholder="支付宝应用 APPID，如 2021000000000000">
            </div>
        </div>

        <div class="form-row">
            <label>应用私钥 <em>*</em></label>
            <div class="form-control">
                <textarea name="alipay_private_key" rows="5" placeholder="粘贴应用私钥（可含 PEM 头尾，系统会自动去除换行）"><?= e($g('alipay_private_key')) ?></textarea>
                <small>RSA2 私钥，PKCS8 或 PKCS1 均可</small>
            </div>
        </div>

        <div class="form-row">
            <label>支付宝公钥 <em>*</em></label>
            <div class="form-control">
                <textarea name="alipay_public_key" rows="5" placeholder="粘贴支付宝公钥（从开放平台复制）"><?= e($g('alipay_public_key')) ?></textarea>
                <small>注意：是「支付宝公钥」，不是你自己生成的应用公钥</small>
            </div>
        </div>

        <div class="form-row">
            <label>异步通知地址（notify_url）</label>
            <div class="form-control">
                <input type="text" name="alipay_notify_url" value="<?= e($g('alipay_notify_url')) ?>" placeholder="<?= e($suggestNotify) ?>">
                <small>留空则自动使用：<code><?= e($suggestNotify) ?></code>（必须是公网可访问地址）</small>
            </div>
        </div>

        <div class="form-row">
            <label>同步跳转地址（return_url）</label>
            <div class="form-control">
                <input type="text" name="alipay_return_url" value="<?= e($g('alipay_return_url')) ?>" placeholder="<?= e($suggestReturn) ?>">
                <small>留空则自动使用：<code><?= e($suggestReturn) ?></code></small>
            </div>
        </div>

        <div class="form-row">
            <label>演示支付</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="demo_pay_enabled" value="1" <?= $g('demo_pay_enabled', '1') === '1' ? 'checked' : '' ?>>
                    开启（收银台显示「模拟支付成功」按钮，仅供演示）
                </label>
                <label class="radio">
                    <input type="radio" name="demo_pay_enabled" value="0" <?= $g('demo_pay_enabled') === '0' ? 'checked' : '' ?>>
                    关闭（正式运营请务必关闭）
                </label>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">保存配置</button>
            <button class="btn btn-outline" type="button" id="btnTest">测试接口连通性</button>
            <button class="btn btn-ghost" type="button" id="btnGenKey">生成新密钥对</button>
        </div>
    </form>

    <div id="testResult" class="test-result"></div>
    <div id="keyResult" class="test-result"></div>
</div>

<script>
(function () {
    var testBtn = document.getElementById('btnTest');
    if (testBtn) {
        testBtn.addEventListener('click', function () {
            var el = document.getElementById('testResult');
            el.className = 'test-result show';
            el.textContent = '正在测试...';
            fetch('<?= url('admin/setting/test') ?>', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: '_token=<?= e($__csrf) ?>'
            })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                el.className = 'test-result show ' + (d.code === 0 ? 'ok' : 'err');
                el.textContent = d.msg;
            })
            .catch(function (e) {
                el.className = 'test-result show err';
                el.textContent = '请求失败：' + e.message;
            });
        });
    }
})();
</script>

<?php elseif ($tab === 'yipay'): ?>

<div class="card">
    <div class="card-head">
        <h3>易支付配置（彩虹易支付 / 码支付等标准协议）</h3>
        <?php if ($yipayReady): ?>
            <span class="badge badge-ok">已启用</span>
        <?php else: ?>
            <span class="badge badge-warn">未启用</span>
        <?php endif; ?>
    </div>

    <div class="notice-box small">
        <h4>接入说明</h4>
        <ul>
            <li>易支付为第三方聚合支付平台，需在平台注册商户后获取 <b>商户 PID</b> 与 <b>商户密钥 KEY</b>。</li>
            <li>「接口地址」填平台首页域名即可（如 <code>pay.example.com</code>），系统自动请求 <code>submit.php</code> / <code>mapi.php</code>。</li>
            <li>收银台模式：<b>页面跳转</b> 下单后直接跳转平台收银台；<b>API 取码</b> 在本站展示二维码并自动轮询支付结果。</li>
            <li>请把下方给出的 <b>异步通知地址</b> 填入易支付商户后台（若平台支持配置），留空则随订单参数自动携带。</li>
            <li>易支付与支付宝官方接口互相独立、可同时启用，用户下单时自行选择支付方式。</li>
        </ul>
    </div>

    <form method="post" action="<?= url('admin/setting/save') ?>" class="form-horizontal">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="group" value="yipay">

        <div class="form-row">
            <label>启用易支付</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="yipay_switch" value="1" <?= $g('yipay_switch', '0') === '1' ? 'checked' : '' ?>>
                    开启（商品页显示易支付方式）
                </label>
                <label class="radio">
                    <input type="radio" name="yipay_switch" value="0" <?= $g('yipay_switch', '0') !== '1' ? 'checked' : '' ?>>
                    关闭
                </label>
            </div>
        </div>

        <div class="form-row">
            <label>支付通道 <em>*</em></label>
            <div class="form-control">
                <label style="display:inline-block;margin-right:18px"><input type="checkbox" name="yipay_channels[]" value="alipay" <?= in_array('alipay', \App\Models\Setting::yipayChannels(), true) ? 'checked' : '' ?>> 支付宝</label>
                <label style="display:inline-block;margin-right:18px"><input type="checkbox" name="yipay_channels[]" value="wxpay" <?= in_array('wxpay', \App\Models\Setting::yipayChannels(), true) ? 'checked' : '' ?>> 微信支付</label>
                <label style="display:inline-block;margin-right:18px"><input type="checkbox" name="yipay_channels[]" value="qqpay" <?= in_array('qqpay', \App\Models\Setting::yipayChannels(), true) ? 'checked' : '' ?>> QQ 钱包</label>
                <small>勾选的通道会显示在商品购买页，由用户自选；至少勾选一个</small>
            </div>
        </div>

        <div class="form-row">
            <label>接口地址 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="yipay_api_url" value="<?= e($g('yipay_api_url')) ?>" placeholder="如 https://pay.example.com 或 pay.example.com" maxlength="200">
                <small>易支付平台首页地址，http(s):// 可省略，末尾无需斜杠</small>
            </div>
        </div>

        <div class="form-row">
            <label>商户 PID <em>*</em></label>
            <div class="form-control">
                <input type="text" name="yipay_pid" value="<?= e($g('yipay_pid')) ?>" placeholder="易支付商户 ID，纯数字" maxlength="32">
            </div>
        </div>

        <div class="form-row">
            <label>商户密钥 KEY <em>*</em></label>
            <div class="form-control">
                <input type="password" name="yipay_key" value="" placeholder="<?= $g('yipay_key') !== '' ? '已保存，留空表示不修改' : '易支付商户通信密钥' ?>" autocomplete="new-password" maxlength="64">
                <small class="form-tip">出于安全考虑不回显已保存的值，留空即保持原密钥不变</small>
            </div>
        </div>

        <div class="form-row">
            <label>收银台模式</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="yipay_mode" value="jump" <?= $g('yipay_mode', 'jump') === 'jump' ? 'checked' : '' ?>>
                    页面跳转（下单后跳转到易支付收银台，兼容性最好）
                </label>
                <label class="radio">
                    <input type="radio" name="yipay_mode" value="api" <?= $g('yipay_mode') === 'api' ? 'checked' : '' ?>>
                    API 取码（本站内展示二维码，需平台支持 mapi.php）
                </label>
                <small>用户在支付页仍可自行切换通道；此为默认发起方式</small>
            </div>
        </div>

        <div class="form-row">
            <label>异步通知地址（notify_url）</label>
            <div class="form-control">
                <input type="text" name="yipay_notify_url" value="<?= e($g('yipay_notify_url')) ?>" placeholder="<?= e($yipaySuggestNotify) ?>">
                <small>留空则自动使用：<code><?= e($yipaySuggestNotify) ?></code>（必须是公网可访问地址）</small>
            </div>
        </div>

        <div class="form-row">
            <label>同步跳转地址（return_url）</label>
            <div class="form-control">
                <input type="text" name="yipay_return_url" value="<?= e($g('yipay_return_url')) ?>" placeholder="<?= e($yipaySuggestReturn) ?>">
                <small>留空则自动使用：<code><?= e($yipaySuggestReturn) ?></code></small>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">保存配置</button>
        </div>
    </form>
</div>

<?php elseif ($tab === 'donate'): ?>

<div class="card">
    <div class="card-head">
        <h3>捐赠收款码</h3>
        <?php if (!empty($donateReady)): ?>
            <span class="badge badge-ok">已启用</span>
        <?php else: ?>
            <span class="badge badge-warn">未就绪</span>
        <?php endif; ?>
    </div>

    <div class="notice-box small">
        <h4>这是什么</h4>
        <ul>
            <li>「捐赠支付」是<b>无需支付接口的个人收款方式</b>：买家下单时默认选中该方式，
                点击即弹出你上传的<b>支付宝 / 微信两张收款码</b>，买家扫码付款后点击「我已完成付款」。</li>
            <li>订单不会自动发货（没有支付回调）。买家声明付款后，订单在<b>「订单管理」中标记为「待核验」</b>，
                你核实到账后点「确认收款并发货」即可走自动发货流程。</li>
            <li>上传后<b>立即生效</b>；启用至少需要一张收款码。建议使用正方形原图，避免截图压缩过度导致无法识别。</li>
        </ul>
    </div>

    <form method="post" action="<?= url('admin/setting/save') ?>" class="form-horizontal">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="group" value="donate">

        <div class="form-row">
            <label>启用捐赠支付</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="donate_enabled" value="1" <?= $g('donate_enabled', '0') === '1' ? 'checked' : '' ?>>
                    开启（下单页默认选中「捐赠支付」，并显示收款码弹窗）
                </label>
                <label class="radio">
                    <input type="radio" name="donate_enabled" value="0" <?= $g('donate_enabled', '0') !== '1' ? 'checked' : '' ?>>
                    关闭
                </label>
                <small>需至少上传一张收款码后，前台才会出现该支付方式。</small>
            </div>
        </div>

        <div class="form-row">
            <label>付款说明</label>
            <div class="form-control">
                <input type="text" name="donate_desc" value="<?= e($g('donate_desc')) ?>" maxlength="200"
                       placeholder="扫描下方收款码完成付款，付款后点击「我已完成付款」…">
                <small>展示在收款码弹窗与支付页顶部，告诉买家付款后该做什么。</small>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">保存配置</button>
        </div>
    </form>

    <div class="form-row" style="margin-top:18px">
        <label>收款码图片</label>
        <div class="form-control">
            <div class="donate-qr-grid">
                <?php foreach ([['ali', '支付宝收款码', 'qr_ali'], ['wechat', '微信收款码', 'qr_wechat']] as [$which, $label, $field]): ?>
                    <?php $qrPath = \App\Models\Setting::donateQr($which); ?>
                    <div class="donate-qr-box">
                        <div class="dq-label"><?= e($label) ?></div>
                        <div class="dq-preview">
                            <?php if ($qrPath !== ''): ?>
                                <img src="<?= e(base_url($qrPath)) ?>" alt="<?= e($label) ?>">
                            <?php else: ?>
                                <span class="dq-empty">未上传</span>
                            <?php endif; ?>
                        </div>
                        <?php if ($qrPath !== ''): ?>
                        <form method="post" action="<?= url('admin/setting/removeDonate') ?>" class="dq-actions"
                              onsubmit="return confirm('确定移除<?= e($label) ?>？移除后前台立即不再展示。')">
                            <?= \App\Auth::csrfField() ?>
                            <input type="hidden" name="which" value="<?= e($which) ?>">
                            <button class="btn btn-outline btn-sm" type="submit">移除</button>
                        </form>
                        <?php endif; ?>
                        <form method="post" action="<?= url('admin/setting/uploadDonate') ?>" enctype="multipart/form-data" class="dq-actions">
                            <?= \App\Auth::csrfField() ?>
                            <input type="hidden" name="which" value="<?= e($which) ?>">
                            <input type="file" name="<?= e($field) ?>" accept=".jpg,.jpeg,.png,.webp" required>
                            <button class="btn btn-primary btn-sm" type="submit"><?= $qrPath !== '' ? '重新上传' : '上传' ?></button>
                        </form>
                        <small class="dq-hint">JPG / PNG / WebP，≤2MB</small>
                    </div>
                <?php endforeach; ?>
            </div>
            <small>图片保存在站点 <code>uploads/donate/</code> 目录，上传后旧图自动清理。两张码都未上传时，前台不会出现「捐赠支付」选项。</small>
        </div>
    </div>
</div>

<?php elseif ($tab === 'site'): ?>

<div class="card">
    <div class="card-head"><h3>站点设置</h3></div>

    <form method="post" action="<?= url('admin/setting/save') ?>" class="form-horizontal">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="group" value="site">

        <div class="form-row">
            <label>网站名称</label>
            <div class="form-control">
                <input type="text" name="site_name" value="<?= e($g('site_name', 'LY云计算')) ?>" maxlength="60">
            </div>
        </div>

        <div class="form-row">
            <label>网站副标题</label>
            <div class="form-control">
                <input type="text" name="site_subtitle" value="<?= e($g('site_subtitle')) ?>" maxlength="120">
            </div>
        </div>

        <div class="form-row">
            <label>SEO 关键词</label>
            <div class="form-control">
                <input type="text" name="site_keywords" value="<?= e($g('site_keywords')) ?>" maxlength="240">
            </div>
        </div>

        <div class="form-row">
            <label>SEO 描述</label>
            <div class="form-control">
                <textarea name="site_description" rows="3" maxlength="400"><?= e($g('site_description')) ?></textarea>
            </div>
        </div>

        <div class="form-row">
            <label>网站公告</label>
            <div class="form-control">
                <textarea name="site_announce" rows="3" maxlength="500"><?= e($g('site_announce')) ?></textarea>
                <small>打开网站即弹出公告窗口（支持多行）；访客关闭后本次会话不再弹出，公告内容更新后会自动重新弹出。留空则不显示</small>
            </div>
        </div>

        <div class="form-row">
            <label>购买须知</label>
            <div class="form-control">
                <textarea name="site_notice" rows="5" maxlength="1000"><?= e($g('site_notice')) ?></textarea>
            </div>
        </div>

        <div class="form-row">
            <label>ICP 备案号</label>
            <div class="form-control">
                <input type="text" name="site_icp" value="<?= e($g('site_icp')) ?>" maxlength="80">
            </div>
        </div>

        <div class="form-row">
            <label>客服 QQ</label>
            <div class="form-control">
                <input type="text" name="site_contact_qq" value="<?= e($g('site_contact_qq')) ?>" maxlength="40">
            </div>
        </div>

        <div class="form-row">
            <label>客服 Telegram</label>
            <div class="form-control">
                <input type="text" name="site_contact_tg" value="<?= e($g('site_contact_tg')) ?>" maxlength="60">
            </div>
        </div>

        <div class="form-row">
            <label>订单超时（分钟）</label>
            <div class="form-control">
                <input type="number" name="order_expire_min" value="<?= e($g('order_expire_min', '5')) ?>" min="1" max="1440">
                <small>超过该时间未支付的订单将被自动关闭，并释放库存、退回优惠券与余额抵扣款；填 0 表示不自动关闭</small>
            </div>
        </div>

        <div class="form-row">
            <label>自动关单计划任务</label>
            <div class="form-control">
                <input type="text" readonly value="<?= e(base_url('index.php?r=cron/tick&key=' . \App\Models\Setting::get('cron_key', ''))) ?>" onclick="this.select()">
                <small>建议在宝塔「计划任务 → Shell 脚本」添加每分钟执行：<code>curl -s "以上URL"</code>。未配置时系统在页面被访问时自动清理，无人访问时段由该任务兜底</small>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">保存设置</button>
        </div>
    </form>
</div>

<?php elseif ($tab === 'mnbt'): ?>

<div class="card">
    <div class="card-head">
        <h3>MNBT 主机自动开通（梦奈宝塔主机系统）</h3>
        <?php if ($mnbtReady): ?>
            <span class="badge badge-ok">已启用</span>
        <?php else: ?>
            <span class="badge badge-warn">未启用</span>
        <?php endif; ?>
    </div>

    <div class="notice-box small">
        <h4>这是什么</h4>
        <ul>
            <li>MNBT（梦奈宝塔主机系统）把宝塔面板封装成可售卖的虚拟主机。本站对接后，
                <b>商品可设为「MNBT 实时开通」</b> —— 买家支付成功时立即调用 MNBT 接口开出一台主机，
                买家在订单页直接看到主机账号/密码与控制面板入口，无需你手动操作。</li>
            <li>与「库存池卡密」模式并存：老商品仍走预录库存分配，互不影响。每个商品可单独选择交付方式。</li>
            <li>MNBT 接口<b>无签名，仅靠参数鉴权</b>，请务必使用 <b>HTTPS</b> 地址，并妥善保管密钥。</li>
        </ul>
    </div>

    <div class="notice-box small">
        <h4>参数从哪来</h4>
        <ol>
            <li><b>接口地址</b>：你部署 MNBT 的站点地址，如 <code>https://mnbt.example.com</code>（可直接粘贴带 <code>/api/api.php</code> 的完整地址，系统会自动裁剪）。站点若套了 Cloudflare 等并开启<b>强制 HTTPS</b>，必须填 <code>https://</code> 开头——填 http 会被 301 重定向导致对接失败。</li>
            <li><b>宝塔编号 mn_bh</b> 与 <b>宝塔调用密钥 mn_keye</b>：登录 MNBT 后台 →「宝塔列表」中查看。</li>
            <li><b>API 密钥 mn_key</b>：MNBT 后台 →「系统设置 → API 设置」中查看或修改。</li>
            <li><b>版本号 mn_vs</b>：MNBT 主版本号去小数点，如 v1.6 填 <code>16</code>、v1.7 填 <code>17</code>、v1.82 填 <code>182</code>（直接填 1.82 也会自动转为 182）。填错会返回「版本不匹配」。</li>
        </ol>
    </div>

    <form method="post" action="<?= url('admin/setting/save') ?>" class="form-horizontal" id="mnbtForm">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="group" value="mnbt">

        <div class="form-row">
            <label>启用 MNBT 对接</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="mnbt_switch" value="1" <?= $g('mnbt_switch', '0') === '1' ? 'checked' : '' ?>>
                    开启（交付方式为「MNBT 实时开通」的商品会在支付后自动开通主机）
                </label>
                <label class="radio">
                    <input type="radio" name="mnbt_switch" value="0" <?= $g('mnbt_switch', '0') !== '1' ? 'checked' : '' ?>>
                    关闭
                </label>
                <small>关闭后不影响已开通的主机与历史订单；已配 MNBT 的商品会转为「待重试」状态，恢复后自动补开。</small>
            </div>
        </div>

        <div class="form-row">
            <label>接口地址 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="mnbt_api_url" value="<?= e($g('mnbt_api_url')) ?>"
                       placeholder="如 https://mnbt.example.com" maxlength="200">
                <small>MNBT 站点根地址；系统自动请求 <code>{地址}/api/api.php?gn=xxx</code>。站点若开启强制 HTTPS（如 Cloudflare），必须填 <code>https://</code> 开头，填 http 会收到 301 重定向导致对接失败</small>
            </div>
        </div>

        <div class="form-row">
            <label>宝塔编号 mn_bh <em>*</em></label>
            <div class="form-control">
                <input type="text" name="mnbt_bh" value="<?= e($g('mnbt_bh')) ?>" placeholder="如 fw12201" maxlength="64">
                <small>MNBT 后台「宝塔列表」中查看</small>
            </div>
        </div>

        <div class="form-row">
            <label>API 密钥 mn_key <em>*</em></label>
            <div class="form-control">
                <input type="password" name="mnbt_key" value=""
                       placeholder="<?= $g('mnbt_key') !== '' ? '已保存，留空表示不修改' : 'MNBT 系统设置 → API 设置中的密钥' ?>"
                       autocomplete="new-password" maxlength="128">
                <small class="form-tip">出于安全考虑不回显已保存的值，留空即保持原密钥不变</small>
            </div>
        </div>

        <div class="form-row">
            <label>宝塔调用密钥 mn_keye <em>*</em></label>
            <div class="form-control">
                <input type="password" name="mnbt_keye" value=""
                       placeholder="<?= $g('mnbt_keye') !== '' ? '已保存，留空表示不修改' : 'MNBT 后台「宝塔列表」中的调用密钥' ?>"
                       autocomplete="new-password" maxlength="128">
                <small class="form-tip">留空即保持原密钥不变</small>
            </div>
        </div>

        <div class="form-row">
            <label>版本号 mn_vs <em>*</em></label>
            <div class="form-control">
                <input type="text" name="mnbt_vs" value="<?= e($g('mnbt_vs', '16')) ?>" placeholder="如 182" maxlength="4" style="width:120px">
                <small>MNBT 主版本号去小数点：v1.6 → <code>16</code>，v1.7 → <code>17</code>，v1.82 → <code>182</code>（直接填 1.82 会自动转为 182）。填错会返回「版本不匹配」</small>
            </div>
        </div>

        <div class="form-row">
            <label>开通失败重试次数</label>
            <div class="form-control">
                <input type="number" name="mnbt_max_retry" value="<?= e($g('mnbt_max_retry', '2')) ?>" min="0" max="10" step="1" style="width:120px">
                <small>
                    支付回调中开通失败（网络抖动 / 宝塔 API 超时）时，订单进入「待重试」，
                    由计划任务自动重试该次数。<b>重试仍失败才自动退款到买家余额</b>。
                    这样可避免「主机已开出但被误判失败而退款」的资损。填 0 表示失败即退款。
                </small>
            </div>
        </div>

        <div class="form-row">
            <label>接口超时（秒）</label>
            <div class="form-control">
                <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
                    <label style="display:flex;align-items:center;gap:6px">
                        连接超时
                        <input type="number" name="mnbt_connect_timeout" value="<?= e($g('mnbt_connect_timeout', '10')) ?>" min="3" max="30" step="1" style="width:90px">
                    </label>
                    <label style="display:flex;align-items:center;gap:6px">
                        总超时
                        <input type="number" name="mnbt_timeout" value="<?= e($g('mnbt_timeout', '15')) ?>" min="5" max="60" step="1" style="width:90px">
                    </label>
                </div>
                <small>开通调用发生在支付回调中，建议总超时 ≤ 15 秒，避免超过支付宝/易支付的回调等待上限</small>
            </div>
        </div>

        <div class="form-row">
            <label>默认账号前缀</label>
            <div class="form-control">
                <input type="text" name="mnbt_default_prefix" value="<?= e($g('mnbt_default_prefix', 'ly')) ?>" placeholder="ly" maxlength="12" style="width:160px">
                <small>
                    新建商品时的默认前缀。实际账号 = <b>前缀 + 订单号后缀</b>，如 <code>ly20261002143012a3f9</code>，
                    全局唯一，无需买家输入。商品可单独覆盖此前缀。
                </small>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">保存配置</button>
            <button class="btn btn-outline" type="button" id="btnTestMnbt">测试连接</button>
            <span id="mnbtTestResult" class="test-result"></span>
            <small style="flex-basis:100%">
                「测试连接」直接使用上方表单的<b>当前值</b>（无需先保存）；密钥输入框留空则沿用已保存的密钥。
                MNBT 站点不可达时最长需等待约 25 秒才有结果，请耐心等待，不要重复点击。
            </small>
        </div>
    </form>
</div>

<script>
(function () {
    var btn = document.getElementById('btnTestMnbt');
    var out = document.getElementById('mnbtTestResult');
    var form = document.getElementById('mnbtForm');
    if (!btn || !form) return;

    // 1.7.12：随「测试连接」提交的表单字段 —— 用表单当前值测试，无需先保存；
    // 密钥输入框留空时不上送，由后端沿用已保存的密钥。
    var FIELDS = ['mnbt_api_url', 'mnbt_bh', 'mnbt_key', 'mnbt_keye', 'mnbt_vs', 'mnbt_timeout', 'mnbt_connect_timeout'];

    btn.addEventListener('click', function () {
        var csrf = form.querySelector('input[name="_token"]');
        btn.disabled = true;
        var old = btn.textContent;
        btn.textContent = '测试中…最长约 25 秒';
        if (out) { out.textContent = '正在连接 MNBT 接口，请耐心等待…'; out.className = 'test-result'; }

        var body = new FormData();
        body.append('_token', csrf ? csrf.value : '');
        FIELDS.forEach(function (n) {
            var el = form.querySelector('[name="' + n + '"]');
            var v = el ? String(el.value).trim() : '';
            if (v !== '') { body.append(n, v); } // 留空 = 沿用已保存值
        });

        // 前端 35 秒兜底超时（后端最长约 连接超时 + 总超时 ≈ 25 秒）
        var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var timer = ctl ? setTimeout(function () { ctl.abort(); }, 35000) : null;

        fetch('<?= url('admin/setting/testMnbt') ?>', { method: 'POST', body: body, credentials: 'same-origin', signal: ctl ? ctl.signal : undefined })
            .then(function (r) { return r.json().catch(function () { return { code: 500, msg: '服务返回异常' }; }); })
            .then(function (j) {
                if (timer) { clearTimeout(timer); }
                btn.disabled = false;
                btn.textContent = old;
                if (out) {
                    out.textContent = (j && j.msg) ? j.msg : '测试失败';
                    out.className = 'test-result ' + ((j && j.code === 0) ? 'ok' : 'err');
                }
            })
            .catch(function (err) {
                if (timer) { clearTimeout(timer); }
                btn.disabled = false;
                btn.textContent = old;
                if (out) {
                    var isAbort = !!(ctl && err && err.name === 'AbortError');
                    out.textContent = isAbort
                        ? '测试超时（超过 35 秒未返回），请检查接口地址是否可达、超时设置是否过大'
                        : '网络异常，请稍后重试';
                    out.className = 'test-result err';
                }
            });
    });
})();
</script>

<?php elseif ($tab === 'mail'): ?>

<div class="card">
    <div class="card-head">
        <h3>SMTP 邮件配置</h3>
        <span class="badge <?= empty($smtpReady) ? 'badge-warn' : 'badge-ok' ?>">
            <?= empty($smtpReady) ? '未配置' : '已配置' ?>
        </span>
    </div>

    <div class="notice-box small" style="margin:0 20px 18px;">
        <h4>配置步骤（以 QQ 邮箱为例）</h4>
        <ol>
            <li>登录 QQ 邮箱 → <b>设置 → 账号</b> → 找到「IMAP/SMTP服务」→ 开启</li>
            <li>按提示发送短信，获取 <b>16 位授权码</b>（<b>不是 QQ 登录密码</b>）</li>
            <li>服务器填 <code>smtp.qq.com</code>，端口 <code>465</code>，加密方式选 <b>SSL</b></li>
            <li>账号填完整邮箱地址，密码栏填<b>授权码</b></li>
            <li>发件人邮箱与账号保持一致，保存后点「发送测试邮件」验证</li>
        </ol>
        <p>其他常见服务商：<code>smtp.163.com:465(SSL)</code>、<code>smtp.exmail.qq.com:465(SSL)</code>、<code>smtp.gmail.com:587(TLS)</code></p>
    </div>

    <form method="post" action="<?= url('admin/setting/save') ?>" class="form-horizontal" id="mailForm">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="group" value="mail">

        <div class="form-row">
            <label>邮件服务</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="smtp_enabled" value="1" <?= $g('smtp_enabled', '0') === '1' ? 'checked' : '' ?>>
                    <span>开启</span>
                </label>
                <label class="radio">
                    <input type="radio" name="smtp_enabled" value="0" <?= $g('smtp_enabled', '0') !== '1' ? 'checked' : '' ?>>
                    <span>关闭</span>
                </label>
                <small class="form-tip">关闭后系统不发送任何邮件；注册验证码也会自动降级为不校验</small>
            </div>
        </div>

        <div class="form-row">
            <label>SMTP 服务器 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="smtp_host" value="<?= e($g('smtp_host')) ?>" placeholder="如 smtp.qq.com" maxlength="120">
            </div>
        </div>

        <div class="form-row">
            <label>端口 <em>*</em></label>
            <div class="form-control">
                <input type="number" name="smtp_port" value="<?= e($g('smtp_port', '465')) ?>" min="1" max="65535" style="max-width:160px">
                <small class="form-tip">SSL 常用 465，STARTTLS 常用 587</small>
            </div>
        </div>

        <div class="form-row">
            <label>加密方式 <em>*</em></label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="smtp_encryption" value="ssl" <?= $g('smtp_encryption', 'ssl') === 'ssl' ? 'checked' : '' ?>>
                    <span>SSL（465，推荐）</span>
                </label>
                <label class="radio">
                    <input type="radio" name="smtp_encryption" value="tls" <?= $g('smtp_encryption') === 'tls' ? 'checked' : '' ?>>
                    <span>STARTTLS（587）</span>
                </label>
                <label class="radio">
                    <input type="radio" name="smtp_encryption" value="none" <?= $g('smtp_encryption') === 'none' ? 'checked' : '' ?>>
                    <span>不加密（25，不推荐）</span>
                </label>
            </div>
        </div>

        <div class="form-row">
            <label>发信账号 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="smtp_username" value="<?= e($g('smtp_username')) ?>" placeholder="完整邮箱地址，如 yourname@qq.com" maxlength="120">
            </div>
        </div>

        <div class="form-row">
            <label>授权码 / 密码 <em>*</em></label>
            <div class="form-control">
                <input type="password" name="smtp_password" value="" placeholder="<?= $g('smtp_password') !== '' ? '已保存，留空表示不修改' : 'QQ邮箱请填 16 位授权码，不是登录密码' ?>" autocomplete="new-password">
                <small class="form-tip">出于安全考虑不回显已保存的值，留空即保持原密码不变</small>
            </div>
        </div>

        <div class="form-row">
            <label>发件人邮箱 <em>*</em></label>
            <div class="form-control">
                <input type="email" name="smtp_from_email" value="<?= e($g('smtp_from_email')) ?>" placeholder="通常与发信账号一致" maxlength="120">
            </div>
        </div>

        <div class="form-row">
            <label>发件人名称</label>
            <div class="form-control">
                <input type="text" name="smtp_from_name" value="<?= e($g('smtp_from_name', 'LY云计算')) ?>" placeholder="收件人看到的发件人名称" maxlength="60">
            </div>
        </div>

        <div class="form-row">
            <label>超时（秒）</label>
            <div class="form-control">
                <input type="number" name="smtp_timeout" value="<?= e($g('smtp_timeout', '15')) ?>" min="5" max="60" style="max-width:160px">
                <small class="form-tip">建议 10–20 秒；过长会拖慢发货邮件的后台执行</small>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">保存设置</button>
            <button class="btn btn-outline" type="button" id="btnTestMail">发送测试邮件</button>
            <span class="test-result" id="mailTestResult"></span>
        </div>
    </form>
</div>

<div class="card">
    <div class="card-head">
        <h3>注册与邮箱限制</h3>
        <?php if ($g('register_email_verify', '1') === '1'): ?>
            <?php if (empty($smtpReady)): ?>
                <span class="badge badge-warn">验证码已开启 · 邮件服务未就绪（实际不发送）</span>
            <?php else: ?>
                <span class="badge badge-ok">验证码已生效</span>
            <?php endif; ?>
        <?php else: ?>
            <span class="badge badge-muted">验证码已关闭</span>
        <?php endif; ?>
    </div>

    <?php if ($g('register_email_verify', '1') === '1' && empty($smtpReady)): ?>
    <div class="notice notice-warning" style="margin:18px 22px 0;">
        邮件服务尚未开启或配置不完整，<b>注册验证码当前不会实际发送</b>（注册流程自动降级为不校验）。
        请在上方「SMTP 邮件配置」完成配置并开启邮件服务，两个表单需分别保存。
    </div>
    <?php endif; ?>

    <form method="post" action="<?= url('admin/setting/save') ?>" class="form-horizontal">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="group" value="reg">

        <div class="form-row">
            <label>允许注册的邮箱域名</label>
            <div class="form-control">
                <textarea name="register_email_domains" rows="3" placeholder="qq.com,foxmail.com"
                          style="width:100%;max-width:460px;"><?= e($g('register_email_domains', 'qq.com,foxmail.com')) ?></textarea>
                <small class="form-tip">
                    多个域名用逗号、空格或分号分隔。留空表示<b>不限制</b>任何邮箱。
                    当前：<?php $ds = \App\Models\Setting::registerDomains(); ?>
                    <?= $ds ? '<b>' . e(implode('、', $ds)) . '</b>' : '<b>不限制</b>' ?>
                </small>
            </div>
        </div>

        <div class="form-row">
            <label>注册邮箱验证码</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="register_email_verify" value="1" <?= $g('register_email_verify', '1') === '1' ? 'checked' : '' ?>>
                    <span>开启（推荐）</span>
                </label>
                <label class="radio">
                    <input type="radio" name="register_email_verify" value="0" <?= $g('register_email_verify') === '0' ? 'checked' : '' ?>>
                    <span>关闭</span>
                </label>
                <small class="form-tip">
                    开启后注册必须填写邮件验证码。<b>仅在「邮件服务」已配置并开启时才真正生效</b>，
                    否则注册会自动降级为不校验，避免把站点锁死。
                </small>
            </div>
        </div>

        <div class="form-row">
            <label>图形验证码（防刷邮件）</label>
            <div class="form-control radio-group">
                <label class="radio">
                    <input type="radio" name="captcha_enabled" value="1" <?= $g('captcha_enabled', '1') === '1' ? 'checked' : '' ?>>
                    <span>开启（推荐）</span>
                </label>
                <label class="radio">
                    <input type="radio" name="captcha_enabled" value="0" <?= $g('captcha_enabled') === '0' ? 'checked' : '' ?>>
                    <span>关闭</span>
                </label>
                <small class="form-tip">
                    开启后，用户点击「获取验证码」前必须先通过 <b>GD 图形验证码</b>（4 位字符，点击图片可刷新，
                    5 分钟有效、一次性使用），防止邮箱验证码接口被脚本批量刷取。
                    需要 PHP 已安装 <b>GD 扩展</b>（宝塔默认安装；未安装时请保持关闭，否则无法发送验证码）。
                    仅在「注册邮箱验证码」开启时展示。
                </small>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">保存设置</button>
        </div>
    </form>
</div>

<script>
(function () {
    var btn = document.getElementById('btnTestMail');
    var out = document.getElementById('mailTestResult');
    var form = document.getElementById('mailForm');
    if (!btn || !form) return;

    btn.addEventListener('click', function () {
        var to = prompt('请输入接收测试邮件的邮箱地址：', <?= json_encode($g('smtp_from_email') ?: $g('smtp_username'), JSON_UNESCAPED_UNICODE) ?>);
        if (!to) return;

        var csrf = form.querySelector('input[name="_token"]');
        btn.disabled = true;
        var old = btn.textContent;
        btn.textContent = '发送中…';
        if (out) { out.textContent = ''; out.className = 'test-result'; }

        var body = new FormData();
        body.append('_token', csrf ? csrf.value : '');
        body.append('to', to);

        fetch('<?= url('admin/setting/testMail') ?>', { method: 'POST', body: body, credentials: 'same-origin' })
            .then(function (r) { return r.json().catch(function () { return { code: 500, msg: '服务返回异常' }; }); })
            .then(function (j) {
                btn.disabled = false;
                btn.textContent = old;
                if (out) {
                    out.textContent = (j && j.msg) ? j.msg : '发送失败';
                    out.className = 'test-result ' + ((j && j.code === 0) ? 'ok' : 'err');
                }
            })
            .catch(function () {
                btn.disabled = false;
                btn.textContent = old;
                if (out) { out.textContent = '网络异常，请稍后重试'; out.className = 'test-result err'; }
            });
    });
})();
</script>

<?php else: ?>

<div class="card">
    <div class="card-head"><h3>系统信息</h3></div>
    <table class="kv-table">
        <tr><td>系统名称</td><td>LY云计算 - IPv6宝塔面板主机购买系统</td></tr>
        <tr><td>系统版本</td><td>v<?= e(LY_VERSION) ?></td></tr>
        <tr><td>PHP 版本</td><td><?= PHP_VERSION ?></td></tr>
        <tr><td>MySQL 版本</td><td><?= e(\App\Database::instance()->value('SELECT VERSION()')) ?></td></tr>
        <tr><td>服务器软件</td><td><?= e($_SERVER['SERVER_SOFTWARE'] ?? '未知') ?></td></tr>
        <tr><td>上传限制</td><td><?= e(ini_get('upload_max_filesize')) ?></td></tr>
        <tr><td>OpenSSL</td><td><?= extension_loaded('openssl') ? '已启用（支持支付宝 RSA2 签名）' : '<span class="text-danger">未启用</span>' ?></td></tr>
        <tr><td>cURL</td><td><?= extension_loaded('curl') ? '已启用' : '未启用（将使用 stream 降级）' ?></td></tr>
        <tr><td>数据库字符集</td><td><?= e(\App\Database::instance()->value("SELECT @@character_set_server")) ?></td></tr>
        <tr><td>当前时间</td><td><?= date('Y-m-d H:i:s') ?>（<?= date_default_timezone_get() ?>）</td></tr>
        <tr><td>站点根目录</td><td class="mono"><?= e(LY_ROOT) ?></td></tr>
        <tr><td>后台入口</td><td class="mono"><?= e(base_url('index.php?r=admin/auth/login')) ?></td></tr>
    </table>

    <div class="notice-box small" style="margin-top:20px">
        <h4>安全建议</h4>
        <ul>
            <li>正式运营前请删除 <code>install/</code> 安装目录。</li>
            <li>在「支付宝接口」页将 <b>演示支付</b> 关闭。</li>
            <li>确保站点使用 HTTPS，并为 <code>config/config.php</code> 设置合适的文件权限。</li>
            <li>建议为后台入口增加 IP 白名单或二次验证。</li>
        </ul>
    </div>
</div>

<?php endif; ?>

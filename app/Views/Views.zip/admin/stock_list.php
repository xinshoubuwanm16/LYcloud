<?php /** 后台库存列表 */ ?>
<div class="stat-grid mini">
    <div class="stat-card slim"><div class="sc-body"><span>库存总数</span><strong><?= (int)$stats['total'] ?></strong></div></div>
    <div class="stat-card slim"><div class="sc-body"><span>未售</span><strong class="text-ok"><?= (int)$stats['available'] ?></strong></div></div>
    <div class="stat-card slim"><div class="sc-body"><span>已售</span><strong class="text-muted"><?= (int)$stats['sold'] ?></strong></div></div>
</div>

<div class="card">
    <div class="card-head">
        <h3>库存管理 <small>宝塔面板登录信息</small></h3>
        <div class="head-actions">
            <form class="search-form" method="get" action="<?= url('admin/stock/list') ?>">
                <input type="hidden" name="r" value="admin/stock/list">
                <select name="product_id">
                    <option value="0">全部商品</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?= (int)$p['id'] ?>" <?= (int)$filter['product_id'] === (int)$p['id'] ? 'selected' : '' ?>>
                            <?= e($p['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select name="status">
                    <option value="">全部状态</option>
                    <option value="0" <?= $filter['status'] === '0' ? 'selected' : '' ?>>未售</option>
                    <option value="1" <?= $filter['status'] === '1' ? 'selected' : '' ?>>已售</option>
                </select>
                <input type="text" name="keyword" value="<?= e($filter['keyword']) ?>" placeholder="链接/账号/备注">
                <button class="btn btn-sm btn-ghost" type="submit">筛选</button>
            </form>
            <a class="btn btn-primary btn-sm" href="<?= url('admin/stock/import') ?>">批量导入</a>
            <a class="btn btn-outline btn-sm" href="<?= url('admin/stock/form') ?>">+ 单条添加</a>
        </div>
    </div>

    <?php if (!$rows): ?>
        <div class="empty-line">暂无库存记录，点击「批量导入」粘贴面板信息</div>
    <?php else: ?>
    <form method="post" action="<?= url('admin/stock/batchDelete') ?>" class="js-confirm"
          data-confirm="确定删除勾选的未售库存吗？已售记录不会被删除。">
        <?= \App\Auth::csrfField() ?>
        <table class="table">
            <thead>
                <tr>
                    <th style="width:40px"><input type="checkbox" id="checkAll"></th>
                    <th style="width:60px">ID</th>
                    <th>所属商品</th>
                    <th>面板登录链接</th>
                    <th style="width:130px">面板账号</th>
                    <th style="width:110px">面板密码</th>
                    <th style="width:120px">备注</th>
                    <th style="width:90px">状态</th>
                    <th style="width:150px">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $s): ?>
                <tr>
                    <td>
                        <?php if ((int)$s['status'] === 0): ?>
                            <input type="checkbox" name="ids[]" value="<?= (int)$s['id'] ?>">
                        <?php endif; ?>
                    </td>
                    <td class="mono"><?= (int)$s['id'] ?></td>
                    <td><?= e($s['product_name'] ?? '-') ?></td>
                    <td class="mono truncate" title="<?= e($s['panel_url']) ?>">
                        <a href="<?= e($s['panel_url']) ?>" target="_blank" rel="noopener"><?= e($s['panel_url']) ?></a>
                    </td>
                    <td class="mono"><?= e($s['panel_user']) ?></td>
                    <td class="mono"><?= e($s['panel_pass']) ?></td>
                    <td><?= e($s['remark']) ?></td>
                    <td>
                        <span class="badge <?= (int)$s['status'] === 1 ? 'badge-muted' : 'badge-ok' ?>">
                            <?= (int)$s['status'] === 1 ? '已售' : '未售' ?>
                        </span>
                    </td>
                    <td class="ops">
                        <?php if ((int)$s['status'] === 0): ?>
                            <a class="btn btn-xs btn-ghost" href="<?= url('admin/stock/form', ['id' => (int)$s['id']]) ?>">编辑</a>
                            <button class="btn btn-xs btn-danger" type="submit" formaction="<?= url('admin/stock/delete') ?>"
                                    name="id" value="<?= (int)$s['id'] ?>"
                                    onclick="return confirm('确定删除这条面板信息吗？')">删除</button>
                        <?php elseif ((int)$s['order_id'] > 0): ?>
                            <a class="btn btn-xs btn-ghost" href="<?= url('admin/order/detail', ['id' => (int)$s['order_id']]) ?>">查看订单</a>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="table-foot">
            <button class="btn btn-sm btn-danger" type="submit">删除勾选的未售库存</button>
        </div>
    </form>

    <?= paginate((int)$total, (int)$perPage, (int)$page, 'admin/stock/list', [
        'product_id' => $filter['product_id'],
        'status' => $filter['status'],
        'keyword' => $filter['keyword'],
    ]) ?>
    <?php endif; ?>
</div>

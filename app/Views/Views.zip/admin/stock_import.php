<?php /** 批量导入库存 */ ?>
<div class="card">
    <div class="card-head">
        <h3>批量导入面板信息</h3>
        <a class="btn btn-sm btn-ghost" href="<?= url('admin/stock/list') ?>">← 返回库存列表</a>
    </div>

    <form method="post" action="<?= url('admin/stock/import') ?>">
        <?= \App\Auth::csrfField() ?>

        <div class="form-row">
            <label>选择商品 <em>*</em></label>
            <div class="form-control">
                <select name="product_id" required>
                    <option value="">— 请选择要导入的商品 —</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?= (int)$p['id'] ?>"
                            <?= (int)input('product_id') === (int)$p['id'] ? 'selected' : '' ?>>
                            #<?= (int)$p['id'] ?> <?= e($p['name']) ?>
                            <?= (int)$p['stock_mode'] === 0 ? '（无限库存模式，无需导入）' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <label>面板信息 <em>*</em></label>
            <div class="form-control">
                <textarea name="content" rows="14" required
                    placeholder="每行一条，格式：面板链接|账号|密码|备注（备注可省略）

示例：
http://[2408:8214:1234::1]:8888/abc123|ly_cloud_a1|Pa5sw0rd!|到期 2027-01-01
http://[2408:8214:1234::2]:8888/def456|ly_cloud_a2|Pa5sw0rd!|
http://[2408:8214:1234::3]:8888/ghi789|ly_cloud_a3|Pa5sw0rd!|香港节点

也支持用英文逗号或制表符分隔。"></textarea>
                <small>系统会自动跳过格式不完整的行并给出提示</small>
            </div>
        </div>

        <div class="import-tips">
            <h4>格式说明</h4>
            <ul>
                <li><b>面板链接</b>：宝塔面板完整登录地址，含协议、IP/域名、端口与安全入口，例如 <code>http://[2408:xxxx::1]:8888/abcdef</code></li>
                <li><b>面板账号</b>：宝塔面板登录用户名</li>
                <li><b>面板密码</b>：宝塔面板登录密码</li>
                <li><b>备注</b>（可选）：如到期时间、节点位置等，会展示给买家</li>
                <li>分隔符支持：竖线 <code>|</code>、英文逗号 <code>,</code>、制表符（从 Excel 直接粘贴）</li>
            </ul>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">开始导入</button>
            <a class="btn btn-ghost" href="<?= url('admin/stock/list') ?>">取消</a>
        </div>
    </form>
</div>

<?php
/** 兑换码生成结果（明文仅本次可见） */
?>
<div class="card">
    <?php if (!$result): ?>
        <div class="card-head">
            <h3>兑换码生成结果</h3>
        </div>
        <div class="empty-line">
            没有可展示的兑换码。明文仅在生成后显示一次，如需重新生成请返回列表。
        </div>
        <div class="gen-foot">
            <a class="btn btn-primary" href="<?= url('admin/redeem/list') ?>">返回兑换码列表</a>
        </div>
    <?php else: ?>
        <div class="card-head">
            <h3>兑换码生成成功 <small>共 <?= count($result['codes']) ?> 个</small></h3>
            <div class="head-actions">
                <button class="btn btn-sm btn-primary" type="button" id="copyAllCodes">复制全部</button>
                <a class="btn btn-sm btn-ghost" href="<?= url('admin/redeem/list', ['batch_no' => $result['batch_no']]) ?>">查看该批次</a>
            </div>
        </div>

        <div class="alert-warn-box">
            <strong>请立即复制保存！</strong>
            出于安全考虑，系统只在数据库中保存兑换码的哈希值，<strong>本页面刷新或关闭后将无法再次查看明文</strong>。
        </div>

        <table class="kv-table">
            <tr><td>批次号</td><td class="mono"><?= e($result['batch_no']) ?></td></tr>
            <tr><td>单张面额</td><td class="text-price">¥<?= money($result['amount']) ?></td></tr>
            <tr><td>生成数量</td><td><?= count($result['codes']) ?> 个（总面额 ¥<?= money(bcmul($result['amount'], (string)count($result['codes']), 2)) ?>）</td></tr>
            <tr><td>有效期</td><td><?= $result['ttl_days'] ? (int)$result['ttl_days'] . ' 天' : '永久有效' ?></td></tr>
            <tr><td>生成时间</td><td class="mono"><?= e($result['created']) ?></td></tr>
        </table>

        <div class="code-grid" id="codeGrid">
            <?php foreach ($result['codes'] as $i => $code): ?>
                <div class="code-item">
                    <span class="code-idx"><?= $i + 1 ?></span>
                    <code class="code-text" id="cd<?= $i ?>"><?= e($code) ?></code>
                    <button class="btn btn-xs btn-ghost code-copy" type="button"
                            data-copy-text="<?= e($code) ?>">复制</button>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="gen-foot">
            <a class="btn btn-primary" href="<?= url('admin/redeem/list') ?>">返回兑换码列表</a>
            <span class="c-muted">提示：可将「复制全部」得到的内容粘贴到 Excel 或记事本中保存</span>
        </div>

        <textarea id="codeRaw" hidden><?= e(implode("\n", $result['codes'])) ?></textarea>
    <?php endif; ?>
</div>

<?php if ($result): ?>
<script>
(function () {
    var btn = document.getElementById('copyAllCodes');
    var src = document.getElementById('codeRaw');
    if (!btn || !src) return;
    btn.addEventListener('click', function () {
        var text = src.value;
        var done = function () {
            btn.textContent = '已复制';
            if (window.LY && window.LY.toast) { window.LY.toast('已复制 ' + <?= count($result['codes']) ?> + ' 个兑换码'); }
            setTimeout(function () { btn.textContent = '复制全部'; }, 1600);
        };
        var fail = function () {
            if (window.LY && window.LY.toast) { window.LY.toast('复制失败，请手动选中复制', 'danger'); }
            src.hidden = false;
            src.select();
        };
        if (window.LY && window.LY.copy) {
            window.LY.copy(text).then(done).catch(fail);
        } else if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(done).catch(fail);
        } else {
            fail();
        }
    });
})();
</script>
<?php endif; ?>

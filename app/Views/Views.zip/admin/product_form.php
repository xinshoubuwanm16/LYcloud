<?php /** 商品编辑/新增 */ 
$isEdit = (bool)$product;
$v = function ($key, $default = '') use ($product) {
    if (isset($_POST[$key])) return $_POST[$key];
    return $product[$key] ?? $default;
};
?>
<div class="card">
    <div class="card-head">
        <h3><?= $isEdit ? '编辑商品' : '添加商品' ?></h3>
        <a class="btn btn-sm btn-ghost" href="<?= url('admin/product/list') ?>">← 返回列表</a>
    </div>

    <form method="post" action="<?= url('admin/product/save') ?>" class="form-horizontal">
        <?= \App\Auth::csrfField() ?>
        <input type="hidden" name="id" value="<?= (int)($product['id'] ?? 0) ?>">

        <div class="form-row">
            <label>商品名称 <em>*</em></label>
            <div class="form-control">
                <input type="text" name="name" value="<?= e($v('name')) ?>" placeholder="如：IPv6宝塔面板主机 - 入门版" required maxlength="140">
            </div>
        </div>

        <div class="form-row">
            <label>副标题</label>
            <div class="form-control">
                <input type="text" name="subtitle" value="<?= e($v('subtitle')) ?>" placeholder="如：1核1G / 10M带宽 / 独立IPv6" maxlength="240">
            </div>
        </div>

        <div class="form-row">
            <label>规格描述</label>
            <div class="form-control">
                <input type="text" name="spec" value="<?= e($v('spec')) ?>" placeholder="如：1核 1G内存 20G硬盘 10M带宽" maxlength="240">
            </div>
        </div>

        <div class="form-row">
            <label>商品分类</label>
            <div class="form-control">
                <select name="category_id" style="max-width:280px">
                    <option value="0">未分类</option>
                    <?php foreach (($categories ?? []) as $c): 
                        $cid = (int)$c['id'];
                        $on  = (int)$c['status'] === 1;
                    ?>
                        <option value="<?= $cid ?>" <?= (int)$v('category_id', 0) === $cid ? 'selected' : '' ?>>
                            <?= e($c['name']) ?><?= $on ? '' : '（已隐藏）' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small>
                    <?php if (empty($categories)): ?>
                        还没有分类，<a href="<?= url('admin/category/form') ?>">先去创建一个</a>
                    <?php else: ?>
                        用于前台「全部商品」页的分类筛选与首页分类入口；留空为「未分类」。
                        <a href="<?= url('admin/category/list') ?>">管理分类</a>
                    <?php endif; ?>
                </small>
            </div>
        </div>

        <div class="form-row">
            <label>商品标签</label>
            <div class="form-control">
                <input type="text" name="tags" value="<?= e($v('tags')) ?>" placeholder="多个标签用英文逗号分隔，如：热销,IPv6,秒开">
                <small>显示在商品卡片上的小标签</small>
            </div>
        </div>

        <div class="form-row">
            <label>售价（元）<em>*</em></label>
            <div class="form-control">
                <input type="number" name="price" value="<?= e($v('price', '0.00')) ?>" step="0.01" min="0" required>
                <small>填写 0 表示免费领取，用户下单后无需支付直接自动发货</small>
            </div>
        </div>

        <div class="form-row">
            <label>划线价（元）</label>
            <div class="form-control">
                <input type="number" name="original_price" value="<?= e($v('original_price', '0.00')) ?>" step="0.01" min="0">
                <small>填写后前台显示为优惠划价，留 0 或与售价相同则不显示</small>
            </div>
        </div>

        <div class="form-row">
            <label>封面上传 / 图片地址</label>
            <div class="form-control">
                <input type="text" name="cover" value="<?= e($v('cover')) ?>" placeholder="图片 URL，可留空" maxlength="240">
                <small>可留空，前台使用默认样式卡片</small>
            </div>
        </div>

        <div class="form-row">
            <label>商品详情</label>
            <div class="form-control">
                <textarea name="description" rows="6" placeholder="每行一条配置说明，前台会自动换行显示"><?= e($v('description')) ?></textarea>
            </div>
        </div>

        <div class="form-row">
            <label>有效期</label>
            <div class="form-control">
                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <input type="number" name="duration_value" value="<?= e($v('duration_value', '0')) ?>" min="0" max="999" step="1" style="width:120px">
                    <?php $du = (string)$v('duration_unit', 'month'); ?>
                    <select name="duration_unit" style="width:120px">
                        <?php foreach (\App\Models\Product::DURATION_UNIT_TEXT as $uk => $ut): ?>
                            <option value="<?= e($uk) ?>"<?= $du === $uk ? ' selected' : '' ?>><?= e($uk === 'day' ? '天' : ($uk === 'week' ? '周' : $ut)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <small>填 0 表示永久有效；否则买家支付后从付款时间起算，到期前 7 天系统自动邮件提醒买家，到期后进入「到期管理」待删机列表</small>
            </div>
        </div>

        <div class="form-row">
            <label>每人限购</label>
            <div class="form-control">
                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <input type="number" name="limit_per_user" value="<?= e($v('limit_per_user', '0')) ?>" min="0" max="9999" step="1" style="width:120px">
                    <span>次</span>
                </div>
                <small>填 0 表示不限购。按<strong>已付款订单</strong>计数（待支付、已关闭、已退款的订单不占名额）；达到上限后买家无法再次下单，商品详情页会显示剩余可购次数</small>
            </div>
        </div>

        <div class="form-row">
            <label>交付方式 <em>*</em></label>
            <div class="form-control radio-group">
                <?php $dm = (int)$v('deliver_mode', 1); ?>
                <label class="radio">
                    <input type="radio" name="deliver_mode" value="1" class="dm-radio" <?= $dm === \App\Models\Product::DELIVER_STOCK ? 'checked' : '' ?>>
                    <b>库存池卡密</b> — 后台预录面板信息，支付成功自动分配一条（传统模式）
                </label>
                <label class="radio">
                    <input type="radio" name="deliver_mode" value="2" class="dm-radio" <?= $dm === \App\Models\Product::DELIVER_MNBT ? 'checked' : '' ?>>
                    <b>MNBT 实时开通</b> — 支付成功后调用 MNBT 接口实时开出一台主机，无需预录库存
                    <?php if (empty($mnbtReady)): ?>
                        <span class="badge badge-warn" style="margin-left:6px">MNBT 接口未配置</span>
                    <?php endif; ?>
                </label>
                <label class="radio">
                    <input type="radio" name="deliver_mode" value="3" class="dm-radio" <?= $dm === \App\Models\Product::DELIVER_MANUAL ? 'checked' : '' ?>>
                    <b>人工发货</b> — 支付后不自动发货，由后台手动处理
                </label>
                <small>切换交付方式后，商品的发货逻辑随之改变；已产生的历史订单不受影响</small>
            </div>
        </div>

        <div class="form-row" id="stockModeRow">
            <label>库存模式</label>
            <div class="form-control radio-group">
                <label class="radio"><input type="radio" name="stock_mode" value="1" <?= (int)$v('stock_mode', 1) === 1 ? 'checked' : '' ?>> 使用库存池（需要导入面板信息，售完自动缺货）</label>
                <label class="radio"><input type="radio" name="stock_mode" value="0" <?= (int)$v('stock_mode', 1) === 0 ? 'checked' : '' ?>> 无限库存（不限制数量）</label>
                <small>选择「MNBT 实时开通」时此项无意义（主机由 MNBT 现开，不占用本站库存池）</small>
            </div>
        </div>

        <div class="form-row" id="autoDeliverRow">
            <label>发货方式</label>
            <div class="form-control radio-group">
                <label class="radio"><input type="radio" name="auto_deliver" value="1" <?= (int)$v('auto_deliver', 1) === 1 ? 'checked' : '' ?>> 自动发货（支付成功立即分配面板信息）</label>
                <label class="radio"><input type="radio" name="auto_deliver" value="0" <?= (int)$v('auto_deliver', 1) === 0 ? 'checked' : '' ?>> 人工发货（后台手动指定库存）</label>
                <small>选择「MNBT 实时开通」时此项无意义（MNBT 商品恒为支付后自动开通）</small>
            </div>
        </div>

        <div id="mnbtBlock" style="display:none">
            <div class="notice-box small" style="margin:0 0 16px 0">
                <h4>MNBT 主机规格</h4>
                <p style="margin:6px 0 0">
                    这些参数会在买家支付成功时提交给 MNBT 的 <code>gn=kt</code> 开通接口。
                    主机账号由系统自动生成（<b>前缀 + 订单号后缀</b>，全局唯一），买家无需输入任何账号信息。
                </p>
                <?php if (empty($mnbtReady)): ?>
                    <p style="margin:8px 0 0">
                        <span class="text-danger">⚠ MNBT 接口尚未配置。</span>
                        请先前往 <a href="<?= url('admin/setting/index', ['tab' => 'mnbt']) ?>">系统设置 → MNBT对接</a>
                        填写接口地址与密钥并测试连接，否则该商品无法自动开通主机。
                    </p>
                <?php endif; ?>
            </div>

            <div class="form-row">
                <label>主机账号前缀</label>
                <div class="form-control">
                    <input type="text" name="mnbt_prefix" value="<?= e($v('mnbt_prefix', $mnbtDefaultPrefix ?? 'ly')) ?>"
                           placeholder="ly" maxlength="12" style="width:180px">
                    <small>仅字母/数字/下划线。实际账号 = 前缀 + 订单号后缀，如 <code>ly20261002143012a3f9</code>；留空则用系统默认前缀</small>
                </div>
            </div>

            <div class="form-row">
                <label>网页空间 <em>*</em></label>
                <div class="form-control">
                    <input type="number" name="mnbt_webdx" value="<?= e($v('mnbt_webdx', '1024')) ?>" min="1" max="1048576" step="1" style="width:160px">
                    <span>MB</span>
                </div>
            </div>

            <div class="form-row">
                <label>数据库空间</label>
                <div class="form-control">
                    <input type="number" name="mnbt_sqldx" value="<?= e($v('mnbt_sqldx', '200')) ?>" min="0" max="1048576" step="1" style="width:160px">
                    <span>MB</span>
                </div>
            </div>

            <div class="form-row">
                <label>月流量</label>
                <div class="form-control">
                    <input type="number" name="mnbt_sizemax" value="<?= e($v('mnbt_sizemax', '50')) ?>" min="0" max="1048576" step="1" style="width:160px">
                    <span>GB / 月</span>
                </div>
            </div>

            <div class="form-row">
                <label>最多绑定域名</label>
                <div class="form-control">
                    <input type="number" name="mnbt_ymbds" value="<?= e($v('mnbt_ymbds', '5')) ?>" min="0" max="9999" step="1" style="width:160px">
                    <span>个</span>
                </div>
            </div>

            <div class="form-row">
                <label>产品类型</label>
                <div class="form-control radio-group">
                    <label class="radio"><input type="radio" name="mnbt_type" value="2" <?= (int)$v('mnbt_type', 2) === 2 ? 'checked' : '' ?>> 主机（完整虚拟主机：文件、数据库、域名）</label>
                    <label class="radio"><input type="radio" name="mnbt_type" value="1" <?= (int)$v('mnbt_type', 2) === 1 ? 'checked' : '' ?>> CDN（仅流量转发）</label>
                </div>
            </div>

            <?php if ($isEdit && (int)$v('deliver_mode', 1) === \App\Models\Product::DELIVER_MNBT): ?>
                <div class="form-row">
                    <label>已开通主机</label>
                    <div class="form-control">
                        <small>
                            该商品已通过 MNBT 开通的主机可在
                            <a href="<?= url('admin/order/list') ?>">订单管理</a> 中查看；
                            主机到期的提醒与删机请前往 <a href="<?= url('admin/expire/list') ?>">到期管理</a>。
                        </small>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-row">
            <label>排序权重</label>
            <div class="form-control">
                <input type="number" name="sort" value="<?= e($v('sort', '0')) ?>" step="1">
                <small>数值越大越靠前</small>
            </div>
        </div>

        <div class="form-row">
            <label>销量基数</label>
            <div class="form-control">
                <input type="number" name="sales" value="<?= e($v('sales', '0')) ?>" step="1" min="0">
                <small>前台显示的基础销量（真实销量会在此基础上累加）</small>
            </div>
        </div>

        <div class="form-row">
            <label>上架状态</label>
            <div class="form-control radio-group">
                <label class="radio"><input type="radio" name="status" value="1" <?= (int)$v('status', 1) === 1 ? 'checked' : '' ?>> 上架销售</label>
                <label class="radio"><input type="radio" name="status" value="0" <?= (int)$v('status', 1) === 0 ? 'checked' : '' ?>> 暂不上架</label>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary"><?= $isEdit ? '保存修改' : '创建商品' ?></button>
            <a class="btn btn-ghost" href="<?= url('admin/product/list') ?>">取消</a>
            <?php if ($isEdit): ?>
                <a class="btn btn-outline" style="margin-left:auto"
                   href="<?= url('admin/stock/import', ['product_id' => (int)$product['id']]) ?>">为该商品导入库存</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<script>
(function () {
    var radios  = document.querySelectorAll('.dm-radio');
    var mnbt    = document.getElementById('mnbtBlock');
    var stockRow = document.getElementById('stockModeRow');
    var autoRow  = document.getElementById('autoDeliverRow');
    if (!radios.length) return;

    function sync() {
        var mode = 1;
        for (var i = 0; i < radios.length; i++) {
            if (radios[i].checked) { mode = parseInt(radios[i].value, 10); break; }
        }
        // MNBT 模式：显示规格区块，隐藏库存池/发货方式（无意义）
        if (mnbt)     mnbt.style.display     = (mode === 2) ? '' : 'none';
        if (stockRow) stockRow.style.display = (mode === 2) ? 'none' : '';
        if (autoRow)  autoRow.style.display  = (mode === 2) ? 'none' : '';
    }

    for (var j = 0; j < radios.length; j++) {
        radios[j].addEventListener('change', sync);
    }
    sync();
})();
</script>
